# Debt recovery analysis and predection for future lending and recovery.
Here We uploaded our dataset files till now, file which is zip is the original dataset we downloaded web.
New_ds.csv file has reduced features and dimensions as per cleaning.
